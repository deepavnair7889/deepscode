<?php
$dbCon = mysqli_connect ("localhost", "root", "");
if (mysqli_connect_error()) {
    echo json_encode (['msg' =>'Connection failed!', 'success' => false]);
    die();
}
mysqli_select_db ($dbCon, "employee_management");


if ( isset ($_POST['action']) && $_POST['action'] == 'addEmployee') {
    $aEmpcolumns = isset($_POST['emp_columns']) ? json_decode ($_POST['emp_columns'], true) : null;
    $aOrder   = array_column($aEmpcolumns, 'order');
    array_multisort($aOrder, SORT_ASC, $aEmpcolumns);
    $aFields  = array_column($aEmpcolumns, 'field');
    $aColumns = array_combine($aOrder, $aFields);
    $row  = 0;
    $fileName = isset ($_FILES['empfile']['tmp_name']) ? $_FILES['empfile']['tmp_name'] : '';
    $aInsert = [];
    if (($file = fopen ($fileName, "r")) !== FALSE) {
        while ( ($data = fgetcsv ($file, 1000, ",") ) !== FALSE) {            
            $aData = [];
            $num = count($data);
            if ($num < 5) {
                echo json_encode(['msg' =>'Minimum  5 columns required!', 'success' => false]);
                die();
            }            
            for ($c=0; $c < $num; $c++) {           
                $aData[$aColumns[$c]] = isset($data[$c]) ? trim ($data[$c]): ''; 
            }
            $row++;
            if ($row > 20){
                echo json_encode(['msg' =>'Maximum row count (20) exceeded!', 'success' => false]);
                die();
            }
            $aInsert[] = $aData;       
        }
        fclose($file);
    }   
    if (!empty ($aInsert)) {        
        addEmployee($aInsert) ;
    }
    die();
} else  {
    //getemplee
    $aEmployee = [];
    $query = " SELECT name,code,department,TIMESTAMPDIFF(YEAR, dob, CURDATE()) AS age,
                CONCAT (TIMESTAMPDIFF(YEAR, doj, CURDATE()), '.', TIMESTAMPDIFF(MONTH, doj, CURDATE()) - (TIMESTAMPDIFF(YEAR, doj, CURDATE()) * 12)) 
                AS experience   FROM emp_details
               ORDER BY id DESC ";
    $result = mysqli_query ($dbCon,$query); 
    while($row = mysqli_fetch_assoc($result)) {
        $aEmployee[] = $row;
    }   
    mysqli_close($dbCon);
    echo json_encode(['data' => $aEmployee ,'msg' =>'Data imported successfully', 'success' => true]);
    die();  
 }


/* insert employee data */
function addEmployee($aInsert) {
    global $dbCon;
    $query = " INSERT INTO emp_details (name,code,department,dob,doj,status) VALUES ";
        foreach ($aInsert as $key => $data) {
            $name       = isset($data['name'])       ? ucfirst ($data['name'])      : NULL;
            $department = isset($data['department']) ? ucfirst ($data['department']) : NULL;
            $code       = isset($data['code'])       ? $data['code']       : NULL;
            $dob        = isset($data['dob'])        ? $data['dob'] : NULL;          
            $doj        = isset($data['doj'])        ? $data['doj'] : NULL;
            if ( !checkValue($name, 'string') || !checkValue($department, 'string') || !checkValue($code, 'code') ) {
                echo json_encode(['msg' =>'Invalid data in row '.($key+1), 'success' => false]);
                die();
            } else if ( !checkValue($dob, 'date') || !checkValue($doj, 'date') ) {
                echo json_encode(['msg' =>'Invalid date value in row '.($key+1), 'success' => false]);
                die();
            }
            $dob = date ("Y-m-d", strtotime ($dob));
            $doj = date ("Y-m-d", strtotime ($doj));
            $query .= "('$name', '$code', '$department', '$dob', '$doj',1),";  
        }
    $query = rtrim ($query, ','); 
    mysqli_query($dbCon,$query) ;
    mysqli_close($dbCon);
    echo json_encode(['msg' =>'Data imported successfully', 'success' => true]);
    die();
}

/* validate input */
function checkValue($input,$type) {
    $bError = true;
    if ($input != NULL) {        
        switch ($type) {
            case 'string':                
                $bError =  preg_match ("/^[a-zA-z ]*$/", $input);                 
                break;
            case 'code':                
                $bError =  preg_match ("/^[a-zA-z-0-9]*$/", $input);                 
                break;    
            case 'date':               
                $input  = strtotime($input); 
                if ( strtotime($input) == ''){
                    $bError = true;
                } else {
                    $input = date ("Y-m-d", $input);
                    list ($year, $month, $day) = explode ('-', $input);                     
                    $bError =  checkdate ($month, $day, $year);
                } 
                break;
            default:                
                break;
        }
    }    
    return $bError; 
}









