1. Unzip the folder and move folder under www folder of wamp server.
2. Import sql file added in the folder, Db username is root, no  password set.
3. Sample csv added in the Folder.
4. Developed in PHP version: 7.2.10
5. xamp Control Panel Version: 3.2.2
6. You can access the project url http://localhost/employee/