<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <style type="text/css">
            .form-control option:disabled{
            background: #bfbec5;
            }          
        </style>
    </head>
    <body>
        <h3 align="center">Employee Details</h3>
        <div class="container" style="width:70%;">
            <div>
                <table class="table table-striped emp-table" border="1" style="margin-top: 10px;">
                    <thead>
                        <th>Employee Code</th>
                        <th>Employee Name</th>
                        <th>Department</th>
                        <th>Age</th>
                        <th>Experience in the Organization</th>
                    </thead>
                    <tbody id="emp-rows">
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h4 align="center">Employee Importer</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <label>Choose Field </label>    
                    <select id="fields" class="form-control">
                        <option value=""> ---Choose Field ---</option>
                        <option value="name">Employee Name</option>
                        <option value="code">Employee Code</option>
                        <option value="department">Department</option>
                        <option value="dob">Date of Birth</option>
                        <option value="doj">Date of Joining</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label>Choose column Order in CSV</label>   
                    <select id="order" class="form-control">
                        <option value=""> --- Choose Order in the CSV ---</option>
                        <option value="0">1</option>
                        <option value="1">2</option>
                        <option value="2">3</option>
                        <option value="3">4</option>
                        <option value="4">5</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="button" class="btn btn-primary" value="Add" id="add" style="margin-top: 22px;">
                </div>
            </div>
            <div>
                <table class="table table-striped field-table" border="1" style="margin-top: 10px;">
                    <thead>
                        <th>Field</th>
                        <th>Column order in CSV file</th>
                        <th>Action</th>
                    </thead>
                    <tbody id="added-fields">
                    </tbody>
                </table>
            </div>
        </div>
        <div class="container" style="width:70%; margin-bottom:30px;">
            <div class="row">
                <form enctype="multipart/form-data" id="empform" method="post" >
                    <div class="col-md-8">
                        <input type="file" id="empfile" name="empfile" class="form-control">
                    </div>
                    <div class="col-md-4"> 
                        <input type="submit" class="btn btn-primary" id="upload" value="Import CSV">
                        <input type="reset" class="btn btn-info" id="reset" value="Cancel">
                        <input type="hidden" name="emp-col-data" id="emp-col-data">
                    </div>
            </div>
            </form>  
        </div>
        </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
        <script src="js/employee.js"></script>  
    </body>
</html>