$(document).ready(function(){
    getEmployees();
    var columnOrder = [];
    $("#add").click(function(){     
        var adddedRow   = '';
        var fields =  $("#fields").val();
        var fieldText =  $("#fields option:selected").text();
        var order =  $("#order").val();
        
        if (fields != '' && order != '') {      
            columnOrder.push({"field": fields, "order": order});
            $("#emp-col-data").val(JSON.stringify(columnOrder));
            $("#fields option[value="+fields+"]").attr('disabled','disabled');
            $("#order option[value="+order+"]").attr('disabled','disabled');
            let orderDisplay = parseInt(order)+1;
            adddedRow += '<tr><td>'+fieldText +'</td><td>'+orderDisplay+'</td>';
            adddedRow += '<td><input type="submit" class="remove" value="Remove" data-itemval="'+fields+'" data-orderval="'+order+'">';
            adddedRow += '</td></tr>';
            $("#added-fields").append(adddedRow);        
            $("#order").prop("selectedIndex", 0);
            $("#fields").prop("selectedIndex", 0);
        } else {
            alert('Choose from list');
        }
    });

    $(".field-table #added-fields").on('click','.remove',function(){       
       var fieldname = $(this).data('itemval');
       var ordername = $(this).data('orderval');      
       $("#fields option[value="+fieldname+"]").removeAttr('disabled');
       $("#order option[value="+ordername+"]").removeAttr('disabled');
       $(this).closest('tr').remove();
       $.each(columnOrder, function(i, el){
            if (this.field == fieldname){
                columnOrder.splice(i, 1);                
            }
        });  
    });

    $("#empform").submit(function(e) { 
        e.preventDefault();
        if (columnOrder.length < 5) {
            alert('Please add 5 columns');
            return false;
        }   
        if ($('#empfile').val() == '')  {
            alert('Choose file');
            return false;
        }   
        var formData = new FormData();
        formData.append('empfile', $('#empfile').prop("files")[0]);
        formData.append('emp_columns', JSON.stringify(columnOrder));      
        formData.append('action', 'addEmployee');
        $.ajax({
            type: "POST",
            url: "service/importEmployee.php",
            data: formData,
            dataType: 'json',
            processData: false,
            contentType: false,
            success: function(response) {   
                if (response.success == false){
                    alert(response.msg); 
                } else{
                    getEmployees();
                    $("#reset").trigger('click');
                }                             
            },
            error:function(){
                alert("error");
            }            
        });
    });

    $("#reset").click(function() {        
        columnOrder = [];
        $("#added-fields").html('');
        $("#order option").prop('disabled', false);
        $("#fields option").prop('disabled', false);
        $("#order").prop("selectedIndex", 0);
        $("#fields").prop("selectedIndex", 0);
    });

    function getEmployees() {
        $.ajax({
            type: "POST",
            url: "service/importEmployee.php",
            data: {},
            dataType: 'json',            
            success: function(response) {               
                if (response.success == true) {                    
                    var newRow = '';
                    $.each(response.data, function(i, val) {
                        newRow += '<tr><td>'+val.code +'</td><td>'+val.name+'</td><td>'+val.department+'</td>';
                        newRow += '<td>'+val.age +'</td><td>'+val.experience +'</td></tr>';                    
                    });  
                    $("#emp-rows").html('').append(newRow);                  
                }
            },
            error:function(){
                alert("error");
            }            
        });
    }
  
});